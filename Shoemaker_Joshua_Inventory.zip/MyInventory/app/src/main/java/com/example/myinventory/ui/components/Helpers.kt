package com.example.myinventory.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SmsManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.myinventory.R

object SmsHelper {
    private const val ALERT_PHONE_NUMBER = "5554"

    fun sendLowStockAlert(context: Context, itemName: String, currentQuantity: Int) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) !=
            PackageManager.PERMISSION_GRANTED) {
            return
        }
        try {
            val smsManager = context.getSystemService(SmsManager::class.java)

            val message = context.getString(R.string.zero_quantity, itemName, currentQuantity)

            // Send the text in the background
            smsManager.sendTextMessage(
                ALERT_PHONE_NUMBER,
                null,
                message,
                null,
                null
            )
            Log.d("SmsHelper", context.getString(R.string.sms_successfull))
        } catch (e: Exception) {
            Log.e("SmsHelper", context.getString(R.string.sms_failed), e)
        }
    }
}


