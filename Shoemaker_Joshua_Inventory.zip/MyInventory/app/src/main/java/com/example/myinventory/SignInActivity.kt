package com.example.myinventory

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.TextFieldLineLimits
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.OutlinedSecureTextField
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myinventory.ui.components.AutomaticSmsPermissionLauncher
import com.example.myinventory.ui.theme.MyInventoryTheme
import com.example.myinventory.ui.theme.inputBoxColors
import com.example.myinventory.ui.theme.inverseOnSurfaceLightMediumContrast
import com.example.myinventory.ui.theme.inversePrimaryLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.primaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.primaryLightMediumContrast
import com.example.myinventory.ui.theme.secondaryContainerLightMediumContrast

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AutomaticSmsPermissionLauncher()
            LoginScreen()
        }
    }
}

@Composable
fun LoginImage(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier
            .size(275.dp),
        shape = CircleShape,
        shadowElevation = 8.dp,
    ) {
        Image(
            painter = painterResource(R.drawable.login_image),
            contentDescription = "My Inventory Logo Image",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
        )
    }
}


@Preview(showBackground = true,
    showSystemUi = true)
@Composable
fun LoginScreen() {
    val username = rememberTextFieldState()
    val password = rememberTextFieldState()

    val context = LocalContext.current
    val gridView = Intent(context, GridViewActivity::class.java)
    val signupActivity = Intent(context, SignUpActivity::class.java)
    //TODO: add forgotpassword activity



    var failedLogin by remember { mutableStateOf(false) }

    MyInventoryTheme {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(primaryLightMediumContrast),
        ) { innerPadding ->
            Column( modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize(),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Hero Image
                LoginImage(modifier = Modifier.padding(top = 40.dp))

                // Username Input
                OutlinedTextField(
                    state = username,
                    label = {
                        Text(stringResource(R.string.username))
                    },
                    placeholder = {
                        stringResource(R.string.username)
                    },
                    isError = failedLogin,
                    supportingText = {
                        if (failedLogin) {
                            Text(stringResource(R.string.usrnm_pwrd_error))
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    lineLimits = TextFieldLineLimits.SingleLine,
                    colors = inputBoxColors(),
                    modifier = Modifier
                        .padding(top = 32.dp, bottom = 8.dp)
                        .fillMaxWidth(fraction = 0.75f)
                )
                // Password Input
                OutlinedSecureTextField(
                    state = password,
                    label = { Text(stringResource(R.string.password)) },
                    isError = failedLogin,
                    supportingText = {
                        if (failedLogin) {
                            Text(stringResource(R.string.usrnm_pwrd_error))
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = inputBoxColors(),
                    modifier = Modifier
                        .padding(top = 8.dp, bottom = 8.dp)
                        .fillMaxWidth(fraction = 0.75f)
                )
                FilledTonalButton(
                    onClick = {

                        /*TODO: validate login */

                        context.startActivity(gridView)
                        (context as? Activity)?.finish()},
                    enabled = username.text.isNotEmpty() && password.text.length >= 12,
                    modifier = Modifier
                        .padding(top = 16.dp, bottom = 8.dp)
                        .fillMaxWidth(fraction = 0.35f),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = primaryContainerLightMediumContrast,
                        contentColor = onPrimaryContainerLightMediumContrast,
                        disabledContainerColor = inversePrimaryLightMediumContrast,
                        disabledContentColor = inverseOnSurfaceLightMediumContrast
                    ),
                    content = {Text(stringResource(R.string.login))}
                )

                TextButton(
                    onClick = {
                        context.startActivity(signupActivity)
                    },
                    modifier = Modifier,
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = secondaryContainerLightMediumContrast
                    ),
                    content = {Text(stringResource(R.string.create_account))}
                )
                if (failedLogin) {
                    TextButton(
                        onClick = { /*TODO*/ },
                        modifier = Modifier,
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = secondaryContainerLightMediumContrast
                        ),
                        content = {Text(stringResource(R.string.forgot_password))}
                    )
                }
            }
        }
    }
}