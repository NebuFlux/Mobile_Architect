package com.example.myinventory.ui.components

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.example.myinventory.R
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.shouldShowRationale

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun CameraPermissionWrapper(
    onLaunchCamera: () -> Unit,
    content: @Composable (onClick: () -> Unit) -> Unit
) {
    val context = LocalContext.current
    val cameraPermissionState = rememberPermissionState(Manifest.permission.CAMERA)
    val status = cameraPermissionState.status

    var showSettingsDialog by remember {mutableStateOf(false)}
    var requested by remember {mutableStateOf(false)}
    val onClickLogic = {
        when {
            status.isGranted -> {
                onLaunchCamera()
            }
            status.shouldShowRationale -> {
                requested = true
                cameraPermissionState.launchPermissionRequest()
            }
            else -> {
                if (!status.isGranted && !status.shouldShowRationale) {
                    requested = true
                    cameraPermissionState.launchPermissionRequest()
                }
            }
        }
    }

    content (onClickLogic)

    LaunchedEffect(status, requested){
        if (requested && !status.isGranted && !status.shouldShowRationale){
            requested = false
            showSettingsDialog = true
        } else if (requested && (status.isGranted || status.shouldShowRationale)) {
            requested = false
        }
    }

    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = { Text("Permission Required") },
            text = {
                Text(stringResource(R.string.camera_permission_required))
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showSettingsDialog = false
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            .apply {
                            data = Uri.fromParts("package", context.packageName,
                                null)
                        }
                        context.startActivity(intent)
                    }
                ) {
                    Text(stringResource(R.string.open_settings))
                }
            },
            dismissButton = {
                TextButton(onClick = { showSettingsDialog = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

@OptIn(ExperimentalPermissionsApi::class)@Composable
fun AutomaticSmsPermissionLauncher(
) {
    val smsPermissionState = rememberPermissionState(Manifest.permission.SEND_SMS)
    val status = smsPermissionState.status

    LaunchedEffect(key1 = Unit) {
        if (!status.isGranted) {
            smsPermissionState.launchPermissionRequest()
        }
    }
}

