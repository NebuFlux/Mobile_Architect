package com.example.myinventory.ui.theme

import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable

@Composable
fun inputBoxColors(): TextFieldColors {
    return OutlinedTextFieldDefaults.colors(
        focusedBorderColor = primaryContainerLightMediumContrast,
        unfocusedBorderColor = outlineLightMediumContrast,
        focusedLabelColor = primaryContainerLightMediumContrast)
}