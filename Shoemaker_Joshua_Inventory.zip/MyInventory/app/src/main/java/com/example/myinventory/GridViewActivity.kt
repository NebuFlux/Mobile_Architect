package com.example.myinventory

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.example.myinventory.ui.theme.MyInventoryTheme
import com.example.myinventory.ui.theme.errorContainerLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryLightMediumContrast
import com.example.myinventory.ui.theme.onTertiaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.primaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.secondaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.tertiaryContainerLightMediumContrast


class GridViewActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GridViewScreen()
        }
    }
}

@Composable
fun SearchDialog(onDismiss: () -> Unit,
                 onSearch: (String) -> Unit) {
    var searchQuery by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {Text(stringResource(R.string.search_inventory))},
        text = {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text(stringResource(R.string.search_label)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton ={
            TextButton(
                onClick = {
                onSearch(searchQuery)
                onDismiss()}
            ){
                Text(stringResource(R.string.search))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

@Composable
fun FilterChipView(){
    var selected by remember { mutableStateOf(false) }
    var showDialog by remember { mutableStateOf(false) }

    if (showDialog) {
        SearchDialog(
            onDismiss = { showDialog = false },
            onSearch = {
                selected = it.isNotEmpty()
            /*TODO: perform search*/
            showDialog = false
        }
        )
    }

    FilterChip(
        onClick = {showDialog = true},
        label = { Text("Filter")},
        selected = selected,
        leadingIcon =
            {
                Icon(
                    imageVector =
                        if (selected) {
                            ImageVector.vectorResource(R.drawable.filter_lines)
                        } else {
                            ImageVector.vectorResource(R.drawable.no_filter_lines)
                        },
                    contentDescription = "Filter Icon",
                    modifier = Modifier.size(FilterChipDefaults.IconSize)
                )
            },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = secondaryContainerLightMediumContrast,
            labelColor = onTertiaryContainerLightMediumContrast,
            iconColor = onTertiaryContainerLightMediumContrast,
            selectedContainerColor = tertiaryContainerLightMediumContrast,
            selectedLabelColor = onTertiaryContainerLightMediumContrast,
            selectedLeadingIconColor = onTertiaryContainerLightMediumContrast
        )
    )
}

@Composable
fun ItemCard(inventoryItem: InventoryItem,
             modifier: Modifier = Modifier,
             context: android.content.Context = LocalContext.current) {

    Card(
        onClick = {
            context.startActivity(Intent(context, ItemViewActivity::class.java))
        },
        modifier = modifier
            .size(150.dp),
        colors = CardDefaults.cardColors(
            containerColor = primaryContainerLightMediumContrast
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = MaterialTheme.shapes.medium
    ) {
        Box(modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)){
            Text(inventoryItem.name, modifier = Modifier
                .padding(4.dp)
                .align(Alignment.TopStart),
                color = onPrimaryLightMediumContrast)
            AsyncImage(
                model= inventoryItem.image,
                fallback = painterResource(R.drawable.box_img),
                error = painterResource(R.drawable.box_img),
                contentDescription = "${inventoryItem.name} Image",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxHeight(fraction = 0.65f)
                    .fillMaxWidth(fraction = 0.9f)
                    .clip(MaterialTheme.shapes.medium)
            )
            Text(String.format("$%.2f",inventoryItem.price), modifier = Modifier
                .padding(4.dp)
                .align(Alignment.BottomEnd),
                style = MaterialTheme.typography.labelSmall,
                color = onPrimaryLightMediumContrast)
            Text("QTY: ${inventoryItem.quantity}", modifier = Modifier
                .padding(4.dp)
                .align(Alignment.BottomStart),
                style = MaterialTheme.typography.labelSmall,
                color = onPrimaryLightMediumContrast)

        }
    }
}

@Composable
fun InventoryRow(
    rowItems: List<InventoryItem>,
    modifier: Modifier = Modifier,
    onDeleteRow: () -> Unit
    ) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start,
        modifier = modifier.fillMaxWidth()
    ) {
        IconButton(
            onClick = onDeleteRow,
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Delete,
                contentDescription = "Delete Row",
                tint = errorContainerLightMediumContrast,
                modifier = Modifier.size(32.dp)
            )
        }

        rowItems.forEach { item ->
            ItemCard(
                inventoryItem = item,
                modifier = Modifier
                    .weight(1f)
                    .padding(4.dp)
            )
        }

        if (rowItems.size < 3) {
            repeat(3 - rowItems.size) {
                Box(modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun InventoryGrid(items: List<InventoryItem>, modifier: Modifier = Modifier) {

    val rowItems = remember(items) {items.chunked(3)}

    LazyColumn(
        contentPadding = PaddingValues(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.padding(8.dp)
    ) {
        items(rowItems){row ->
            InventoryRow(rowItems = row){
                /*TODO: create logic to delete items in row*/
            }
        }
    }
}

fun getInventoryItems(): List<InventoryItem> {
    return List(30) {
        index ->
        InventoryItem(
            id = index,
            name = "Item $index",
            price = (0..100).random().toDouble(),
            quantity = (0..25).random(),
            image = null,
            description = "Description for Item $index",
            shelf = (0..10).random(),
            aisle = ('A'..'Z').random()
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true,
    showSystemUi = true)
@Composable
fun GridViewScreen() {
    val context = LocalContext.current
    val addItemActivity = Intent(context, AddItem::class.java)
    val itemView = Intent(context, ItemViewActivity::class.java)


    MyInventoryTheme {
        Scaffold(modifier = Modifier.fillMaxSize(),
        topBar ={
            CenterAlignedTopAppBar(
                title = {Text(stringResource(R.string.my_inventory_title))},
                navigationIcon = {
                    IconButton(
                        onClick = {
                        context.startActivity(addItemActivity)
                        }) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = "Add Item",
                            tint = onPrimaryContainerLightMediumContrast,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }, actions = {
                    FilterChipView()
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = primaryContainerLightMediumContrast,
                    titleContentColor = onPrimaryContainerLightMediumContrast
                )
            )
        }) { innerPadding ->
            InventoryGrid(
                items = getInventoryItems(),
                modifier = Modifier
                    .padding(innerPadding))
        }
    }
}