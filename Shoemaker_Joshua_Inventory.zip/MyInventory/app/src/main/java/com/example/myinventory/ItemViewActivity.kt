package com.example.myinventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.TextFieldLineLimits
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.example.myinventory.ui.components.SmsHelper
import com.example.myinventory.ui.theme.inputBoxColors
import com.example.myinventory.ui.theme.MyInventoryTheme
import com.example.myinventory.ui.theme.errorContainerLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryLightMediumContrast
import com.example.myinventory.ui.theme.primaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.primaryLightMediumContrast
import com.example.myinventory.ui.theme.secondaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.secondaryLightMediumContrast
import com.example.myinventory.ui.theme.tertiaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.tertiaryLightMediumContrast

class ItemViewActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ItemViewScreen()
        }
    }
}

@Composable
fun TickerBox(modifier: Modifier = Modifier, upperclick: () -> Unit, lowerclick: () -> Unit){
    Column{
        IconButton(
            onClick = upperclick,
            modifier = Modifier
                .size(24.dp),
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = primaryLightMediumContrast,
                contentColor = onPrimaryLightMediumContrast
            )){
            Icon(
                imageVector = Icons.Filled.ArrowDropUp,
                contentDescription = stringResource(R.string.increase_quantity)
            )
        }
        IconButton(
            onClick = lowerclick,
            modifier = Modifier
                .size(24.dp),
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = primaryLightMediumContrast,
                contentColor = onPrimaryLightMediumContrast
            )){
            Icon(
                imageVector = Icons.Filled.ArrowDropDown,
                contentDescription = stringResource(R.string.decrease_quantity)
            )
        }
    }
}

@Composable
fun NumericalTickerField(number: Double = 0.0,
                         onValueChange: (Double) -> Unit,
                         modifier: Modifier = Modifier,
                         inputName: String = ""){

    OutlinedTextField(
        value = number.toString(),
        onValueChange = {
            val newValue = it.toDoubleOrNull() ?: 0.0
            onValueChange(newValue)
        },
        modifier = modifier,
        label = {Text(inputName) },
        trailingIcon = {
            TickerBox(
                upperclick = { onValueChange(number + 1.0) },
                lowerclick = { onValueChange(number - 1.0) }
            )
        },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        colors = inputBoxColors()
    )
}

@Composable
fun NumericalTickerField(number: Int = 0,
                         onValueChange: (Int) -> Unit,
                         modifier: Modifier = Modifier,
                         inputName: String = ""){

    OutlinedTextField(
        value = number.toString(),
        onValueChange = {
            val newVal = it.toIntOrNull() ?: 0
            onValueChange(newVal)
        },
        modifier = modifier,
        label = {Text(inputName)},
        trailingIcon = {
            TickerBox(
                upperclick = { onValueChange(number + 1) },
                lowerclick = { onValueChange(number - 1) }
            )
        },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        colors = inputBoxColors()
    )
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItemViewScreen() {
    var item by remember { mutableStateOf(InventoryItem(
        name = "Item Name",
        price = 10.0,
        quantity = 5,
        image = null,
        description = "Item Description",
        shelf = 1,
        aisle = 'A'
    ))}

    var itemCopy by remember { mutableStateOf(item) }
    val openDialog = remember { mutableStateOf(false) }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun NameChangeDialog() {
        val nameState = rememberTextFieldState(itemCopy.name)
        BasicAlertDialog(onDismissRequest = { openDialog.value = false }) {
            Surface(
                modifier = Modifier
                    .wrapContentWidth()
                    .wrapContentHeight(),
                shape = MaterialTheme.shapes.medium,
                tonalElevation = AlertDialogDefaults.TonalElevation,
            ){
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(16.dp)) {
                    Text(stringResource(R.string.change_name))
                    Spacer(modifier = Modifier.height(24.dp))
                    OutlinedTextField(
                        state = nameState,
                        lineLimits = TextFieldLineLimits.SingleLine,
                        colors = inputBoxColors()
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ){
                        TextButton(onClick = { openDialog.value = false },
                            modifier = Modifier.padding(8.dp),
                            colors = ButtonDefaults.textButtonColors(
                                contentColor = tertiaryContainerLightMediumContrast
                            )) {
                            Text(stringResource(R.string.cancel))
                        }
                        TextButton(onClick = {
                            itemCopy = itemCopy.copy(name = nameState.text.toString())
                            openDialog.value = false
                        },
                            modifier = Modifier.padding(8.dp),
                            colors = ButtonDefaults.textButtonColors(
                                contentColor = secondaryContainerLightMediumContrast
                            )) {
                            Text(stringResource(R.string.confirm))
                        }
                    }
                }
            }
        }
    }

    val context = LocalContext.current

    MyInventoryTheme {
        Scaffold(modifier = Modifier.fillMaxSize(),
            topBar ={
                CenterAlignedTopAppBar(
                    title = {Text(stringResource(R.string.item_details))},
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                (context as? android.app.Activity)?.finish()
                            }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = onPrimaryContainerLightMediumContrast,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }, actions = {
                        IconButton(
                            onClick = {
                                /*TODO: delete item*/
                            }) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Delete Item",
                                tint = errorContainerLightMediumContrast,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = primaryContainerLightMediumContrast,
                        titleContentColor = onPrimaryContainerLightMediumContrast
                    )
                )
            }) { innerPadding ->

            Column (modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ){
                if (openDialog.value) {
                    NameChangeDialog()
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(48.dp).padding(4.dp))
                    Text(text = itemCopy.name,
                        style = MaterialTheme.typography.headlineMedium)
                    IconButton(onClick = { openDialog.value = true }) {
                        Icon(
                            imageVector = Icons.Outlined.Edit,
                            contentDescription = "Edit Button",
                            tint = secondaryLightMediumContrast
                        )
                    }
                }

                AsyncImage(
                    model = itemCopy.image,
                    fallback = painterResource(R.drawable.box_img),
                    error = painterResource(R.drawable.box_img),
                    contentDescription = "${itemCopy.name} Image",
                    modifier = Modifier
                )
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                )
                {
                    NumericalTickerField(
                        number = itemCopy.quantity,
                        onValueChange = { itemCopy = itemCopy.copy(quantity = it)},
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 4.dp),
                        inputName = stringResource(R.string.quantity)
                    )
                    NumericalTickerField(
                        number = itemCopy.price,
                        onValueChange = {itemCopy = itemCopy.copy(price = it)},
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 4.dp),
                        inputName = stringResource(R.string.price)
                    )
                }
                HorizontalDivider(
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .padding(vertical = 4.dp)
                        .fillMaxWidth(),
                    thickness = 2.dp,
                    color = primaryLightMediumContrast
                )
                Box(
                    modifier = Modifier
                        .padding(horizontal = 32.dp, vertical = 16.dp)
                        .fillMaxWidth()
                        .height(150.dp)
                ) {
                    Text(
                        stringResource(R.string.location),
                        modifier = Modifier.align(Alignment.TopStart),
                        style = MaterialTheme.typography.titleLarge

                    )
                    LocationDropDown(
                        items = (1..10).map { it.toString() },
                        label = "Shelf",
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .width(150.dp)
                    )
                    LocationDropDown(
                        items = ('A'..'Z').map { it.toString() },
                        label = "Aisle",
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .width(150.dp)
                    )
                }
                OutlinedTextField(
                    value = itemCopy.description ?: "",
                    onValueChange = { itemCopy = itemCopy.copy(description = it)},
                    label = {Text(stringResource(R.string.addItem_description))},
                    modifier = Modifier
                        .fillMaxWidth(fraction = 0.85f)
                        .height(150.dp),
                    maxLines = 5,
                    colors = inputBoxColors()
                )

                FilledTonalButton(
                    onClick = { item = itemCopy
                        if (item.quantity == 0) {
                            SmsHelper.sendLowStockAlert(
                                context = context,
                                itemName = item.name,
                                currentQuantity = 0
                            )
                        }
                              },
                    modifier = Modifier
                        .padding(20.dp),
                    enabled = (itemCopy != item),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = primaryLightMediumContrast,
                        contentColor = onPrimaryLightMediumContrast
                    )
                ) { Text(stringResource(R.string.update)) }
            }
        }
    }
}


@Preview(showBackground = true,
    showSystemUi = true)
@Composable
fun ItemViewScreenPreview(){
    ItemViewScreen()
}