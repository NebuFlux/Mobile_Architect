package com.example.myinventory

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class InventoryItem(
    val id: Int = 0,
    val name: String,
    val price: Double,
    val quantity: Int,
    val image: String?,
    val description: String?,
    val shelf: Int?,
    val aisle: Char?) : Parcelable
