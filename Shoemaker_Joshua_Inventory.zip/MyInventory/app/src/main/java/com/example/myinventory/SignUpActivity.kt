package com.example.myinventory

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.TextFieldLineLimits
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedSecureTextField
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myinventory.ui.theme.inputBoxColors
import com.example.myinventory.ui.theme.MyInventoryTheme
import com.example.myinventory.ui.theme.inverseOnSurfaceLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.onSecondaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.outlineVariantLightMediumContrast
import com.example.myinventory.ui.theme.primaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.secondaryContainerLightMediumContrast

class SignUpActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SignUpScreen()
        }
    }
}

fun validateInputs(uText: String, pText: String, cText: String, eText: String): Array<Boolean> {

    // Check Username
    val usernameError = uText.length < 8 || uText.contains(" ")

    // Check Password (Must be 12+ chars, no spaces, and contain at least one digit and special character)
    val passwordError = pText.length < 12 || pText.contains(" ") || !pText.any { it.isDigit() }
            || !pText.any { "!#$%&*_-@.,?".contains(it) }

    // Check Confirm Password
    val confirmError = cText != pText

    // Check Employee ID
    val employeeIdError = eText.length < 8 || eText.contains(" ") || !eText.all { it.isDigit() }

    return arrayOf(usernameError, passwordError, confirmError, employeeIdError)
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true,
    showSystemUi = true)
@Composable
fun SignUpScreen() {
    // variables to hold user input with recomposition
    val username = rememberTextFieldState()
    val password = rememberTextFieldState()
    val confirmPassword = rememberTextFieldState()
    val employeeID = rememberTextFieldState()

    // booleans to toggle TextField input errors
    var usernameError by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf(false) }
    var confirmError by remember { mutableStateOf(false) }
    var employeeError by remember { mutableStateOf(false) }

    // temporary list of roles for ui development
    val roles = listOf("Laborer", "Supervisor", "Executive")
    //
    var expanded by remember { mutableStateOf(false)}
    val selectedRole = rememberTextFieldState(roles[0])

    val context = LocalContext.current
    val gridView = Intent(context, GridViewActivity::class.java)


    MyInventoryTheme {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                CenterAlignedTopAppBar(
                    title = {Text(stringResource(R.string.sign_up_title))},
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                (context as? android.app.Activity)?.finish()
                            }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = onPrimaryContainerLightMediumContrast
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = primaryContainerLightMediumContrast,
                        titleContentColor = onPrimaryContainerLightMediumContrast
                    )
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // username input
                OutlinedTextField(
                    state = username,
                    label = { Text(stringResource(R.string.username)) },
                    isError = usernameError,
                    supportingText = {
                        if (usernameError) {
                            Text(stringResource(R.string.username_error))
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    lineLimits = TextFieldLineLimits.SingleLine,
                    colors = inputBoxColors(),
                    modifier = Modifier
                        .padding(top = 125.dp, bottom = 4.dp)
                        .fillMaxWidth(fraction = 0.75f)
                )
                // password input
                OutlinedSecureTextField(
                    state = password,
                    label = { Text(stringResource(R.string.password)) },
                    isError = passwordError,
                    supportingText = {
                        if (passwordError) {
                            Text(stringResource(R.string.pwrd_error))
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = inputBoxColors(),
                    modifier = Modifier
                        .padding(vertical = 4.dp)
                        .fillMaxWidth(fraction = 0.75f)
                )
                // confirm password input
                OutlinedSecureTextField(
                    state = confirmPassword,
                    label = { Text(stringResource(R.string.confirm_password)) },
                    isError = confirmError,
                    supportingText = {
                        if (confirmError) {
                            Text(stringResource(R.string.confirm_pwrd_error))
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = inputBoxColors(),
                    modifier = Modifier
                        .padding(vertical = 4.dp)
                        .fillMaxWidth(fraction = 0.75f)
                )
                // Employee ID input
                OutlinedTextField(
                    state = employeeID,
                    label = { Text(stringResource(R.string.employee_id)) },
                    isError = employeeError,
                    supportingText = {
                        if (employeeError) {
                            Text(stringResource(R.string.employeeID_error))
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    lineLimits = TextFieldLineLimits.SingleLine,
                    colors = inputBoxColors(),
                    modifier = Modifier
                        .padding(vertical = 4.dp)
                        .fillMaxWidth(fraction = 0.75f)
                )
                // Account Type dropdown
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded },
                    modifier = Modifier
                        .padding(vertical = 4.dp)
                        .fillMaxWidth(fraction = 0.75f)
                ){
                    OutlinedTextField(
                        state = selectedRole,
                        label = { Text(stringResource(R.string.account_type))},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        colors = inputBoxColors(),
                        modifier = Modifier
                            .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                    ) {
                        roles.forEach { role -> DropdownMenuItem(
                            text = {Text(role)},
                            onClick = {
                                selectedRole.edit {replace(0, length, role) }
                                expanded = false
                            }
                        ) }
                    }
                }
                // Create Account button
                FilledTonalButton(
                    onClick = {
                        val errors = validateInputs(
                            username.text.toString(),
                            password.text.toString(),
                            confirmPassword.text.toString(),
                            employeeID.text.toString())

                        usernameError = errors[0]
                        passwordError = errors[1]
                        confirmError = errors[2]
                        employeeError = errors[3]

                        /*TODO: create account in database */
                        context.startActivity(gridView)
                        (context as? android.app.Activity)?.finish()},

                    enabled = username.text.isNotEmpty() && password.text.length >= 12
                            && confirmPassword.text == password.text,
                    modifier = Modifier
                        .padding(top = 16.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = secondaryContainerLightMediumContrast,
                        contentColor = onSecondaryContainerLightMediumContrast,
                        disabledContainerColor = outlineVariantLightMediumContrast,
                        disabledContentColor = inverseOnSurfaceLightMediumContrast
                    ),
                    content = {Text(stringResource(R.string.create_account))}
                )
            }
        }
    }
}
