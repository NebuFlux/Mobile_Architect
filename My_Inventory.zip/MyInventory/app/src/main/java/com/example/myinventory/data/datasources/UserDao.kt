package com.example.myinventory.data.datasources

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.myinventory.data.models.User

// Data Access Object for accessing User data in the database
@Dao
interface UserDao {

    // Insert a new user into the database
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User): Long

    // Update an existing user's information
    @Update
    suspend fun updateUser(user: User)

    // Delete a user from the database
    @Delete
    suspend fun deleteUser(user: User)

    // Check if a username already exists in the database
    @Query("SELECT EXISTS(SELECT 1 FROM users WHERE userName = :userName)")
    suspend fun isUserNameTaken(userName: String): Boolean

    // Retrieve the password hash for a given username
    @Query("SELECT passwordHash FROM users WHERE userName = :userName")
    suspend fun getPasswordHash(userName: String): String

    // Retrieve the phoneNumber to send alert to
    @Query("SELECT phoneNumber FROM users WHERE UserId = :userId")
    suspend fun getPhoneNumberByID(userId: Long): String

    @Query("SELECT * FROM users WHERE UserId = :userId")
    suspend fun getUserById(userId: Long): User

    @Query("SELECT UserId FROM users WHERE userName = :userName AND passwordHash = :passwordHash")
    suspend fun getUserId(userName: String, passwordHash: String): Long

}
