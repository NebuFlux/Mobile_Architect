package com.example.myinventory.data.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

// Entity class representing a User in the 'users' table
@Entity(tableName = "users",
    indices = [Index(value = ["userName"], unique = true)])
data class User(

    // Primary key for the user, auto-generated
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "UserId")
    val id: Long = 0L,

    // Username for login
    @ColumnInfo(name = "userName")
    val userName: String,

    // Hashed password for security
    @ColumnInfo(name = "passwordHash")
    val passwordHash: String,

    // Employee ID associated with the user
    @ColumnInfo(name = "employeeId")
    val employeeId: Int,

    // Role of the user (e.g., Laborer, Supervisor)
    @ColumnInfo(name = "role")
    val role: String = "Laborer",

    // Phone number for sms alerts
    @ColumnInfo(name = "phoneNumber")
    val phoneNumber: String = ""
){
    // Convenience constructor for creating users without an ID, phoneNumber, or hashed password
    constructor(
        userName: String = "",
        employeeId: Int = 0,
        role: String = "Laborer"
    ): this(
        id = 0,
        userName = userName,
        passwordHash = "",
        employeeId = employeeId,
        role = role,
        phoneNumber = ""
    )
}
