package com.example.myinventory.data.repositories

import androidx.lifecycle.LiveData
import com.example.myinventory.data.datasources.ItemDao
import com.example.myinventory.data.models.Item
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// Repository class to abstract access to Item data
class ItemRepository(private val itemDao: ItemDao) {

    // LiveData observing all items in the database
    val allItems: LiveData<List<Item>> = itemDao.getAllItems()

    // Searches for items matching the query string
    fun searchItems(query: String): LiveData<List<Item>> =
        itemDao.findItems(query)

    // Retrieves a specific item by its ID
    fun getItemById(id: Int): LiveData<Item> =
        itemDao.findItembyId(id)

    // CoroutineScope for performing database operations off the main thread
    private val ioScope = CoroutineScope(Dispatchers.IO)

    // Inserts an item into the database asynchronously
    fun insertItem(item: Item) {
        ioScope.launch{
            itemDao.insertItem(item)
        }
    }

    // Updates an item in the database asynchronously
    fun updateItem(item: Item) {
        ioScope.launch{
            itemDao.updateItem(item)
        }
    }

    // Deletes an item from the database asynchronously
    fun deleteItem(item: Item) {
        ioScope.launch{
            itemDao.deleteItem(item)
        }
    }

    // Deletes multiple items from the database asynchronously
    fun deleteItems(items: List<Item>) {
        ioScope.launch {
            itemDao.deleteItems(items)
        }
    }

}
