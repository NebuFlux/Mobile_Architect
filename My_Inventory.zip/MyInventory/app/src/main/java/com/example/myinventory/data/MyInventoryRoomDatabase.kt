package com.example.myinventory.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.myinventory.data.datasources.ItemDao
import com.example.myinventory.data.datasources.UserDao
import com.example.myinventory.data.models.Item
import com.example.myinventory.data.models.User

// Room Database class for the application
@Database(entities = [Item::class, User::class], version = 1)
abstract class MyInventoryRoomDatabase: RoomDatabase() {

    // Abstract methods to retrieve DAOs
    abstract fun itemDao(): ItemDao
    abstract fun userDao(): UserDao
    
    companion object{
        // Volatile instance to ensure atomic access to the singleton
        @Volatile
        private var INSTANCE: MyInventoryRoomDatabase? = null

        // Singleton provider for the database instance
        fun getDatabase(context: Context): MyInventoryRoomDatabase {
            return INSTANCE ?: synchronized(this){
                val instance = Room.databaseBuilder(
                        context.applicationContext,
                    MyInventoryRoomDatabase::class.java,
                        "MyInventory_database"
                    ).fallbackToDestructiveMigration()
                        .build()

                INSTANCE = instance
                instance
            }
        }
    }
}
