package com.example.myinventory.data.repositories

import com.example.myinventory.data.datasources.UserDao
import com.example.myinventory.data.models.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// Repository class to abstract access to User data
class UserRepository(private val userDao: UserDao) {

    // CoroutineScope for performing database operations off the main thread
    private val ioScope = CoroutineScope(Dispatchers.IO)

    // Inserts a user into the database asynchronously
    suspend fun insertUser(user: User): Long {
          return userDao.insertUser(user)
    }

    // Updates a user in the database asynchronously
    fun updateUser(user: User){
        ioScope.launch{
            userDao.updateUser(user)
        }
    }

    // Get User by userId
    suspend fun getUserById(userId: Long): User{
        return userDao.getUserById(userId)
    }

    // Get User's PhoneNumber
    suspend fun getPhoneNumberById(userId: Long): String {
        return userDao.getPhoneNumberByID(userId)
    }

    // Deletes a user from the database asynchronously
    fun deleteUser(user: User){
        ioScope.launch{
            userDao.deleteUser(user)
        }
    }

    // Checks if a username is already taken
    suspend fun isUserNameTaken(userName: String): Boolean =
        userDao.isUserNameTaken(userName)

    // Retrieves the password hash for authentication
    suspend fun getPasswordHash(userName: String): String =
        userDao.getPasswordHash(userName)

    suspend fun getUserId(userName: String, passwordHash: String): Long =
        userDao.getUserId(userName, passwordHash)
}
