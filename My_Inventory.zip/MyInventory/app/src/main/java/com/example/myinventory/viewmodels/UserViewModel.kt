package com.example.myinventory.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.myinventory.data.MyInventoryRoomDatabase
import com.example.myinventory.data.models.User
import com.example.myinventory.data.repositories.UserRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.mindrot.jbcrypt.BCrypt

// ViewModel for managing User authentication and data operations
class UserViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: UserRepository

    init {
        // Initialize DAO and Repository
        val userDao = MyInventoryRoomDatabase.getDatabase(application).userDao()
        repository = UserRepository(userDao)
    }

    // Check if a username already exists asynchronously
    fun userNameTaken(userName: String, onResult: (Boolean) -> Unit) =
        viewModelScope.launch{
        onResult(repository.isUserNameTaken(userName))
    }

    // Authenticate user by verifying password against stored hash on Background Thread
    fun authenticate(userName: String, password: String, onResult: (Boolean, Long) -> Unit) =
        viewModelScope.launch {
            var storedHash = ""
            val success = withContext(Dispatchers.IO) {
                storedHash = repository.getPasswordHash(userName)
                // Verify password using BCrypt on IO thread to avoid UI freeze
                storedHash.isNotBlank() && BCrypt.checkpw(password, storedHash)
            }
            if (success && storedHash.isNotBlank()) getUserID(userName, storedHash){onResult(success, it)}
            else onResult(success, 0L)
    }

    // Register a new user: Hash password on IO thread then insert
    fun registerUser(user: User, passwordRaw: String, onSuccess: (Long) -> Unit) = viewModelScope.launch {
       val id = withContext(Dispatchers.IO) {
            val hashedPassword = BCrypt.hashpw(passwordRaw, BCrypt.gensalt())
            val newUser = user.copy(passwordHash = hashedPassword)
            repository.insertUser(newUser)
        }
        withContext(Dispatchers.Main) {
            onSuccess(id)
        }
    }

    fun getUserPhoneNumber(userId: Long, getNumber: (String) -> Unit) = viewModelScope.launch{
        getNumber(withContext(Dispatchers.IO){
            repository.getPhoneNumberById(userId)?: ""
        })
    }

    fun getUserById(userId: Long, onResult: (User) -> Unit) = viewModelScope.launch {
        onResult (withContext(Dispatchers.IO){
            repository.getUserById(userId)
        })
    }

    fun updateUser(user: User) = viewModelScope.launch{
        repository.updateUser(user)
    }

    fun getUserID(userName: String, passwordHash: String, onResult: (Long) -> Unit) = viewModelScope.launch {
        onResult(withContext(Dispatchers.IO){repository.getUserId(userName, passwordHash)
    })}
}
