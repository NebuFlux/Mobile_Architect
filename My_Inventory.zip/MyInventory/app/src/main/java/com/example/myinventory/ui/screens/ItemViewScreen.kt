package com.example.myinventory.ui.screens

import android.content.Intent
import android.icu.text.NumberFormat
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.example.myinventory.R
import com.example.myinventory.ui.components.CameraPermissionWrapper
import com.example.myinventory.ui.components.SmsHelper
import com.example.myinventory.ui.components.SmsPermissionWrapper
import com.example.myinventory.ui.components.createTempImageUri
import com.example.myinventory.ui.theme.errorContainerLightMediumContrast
import com.example.myinventory.ui.theme.inputBoxColors
import com.example.myinventory.ui.theme.onPrimaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryLightMediumContrast
import com.example.myinventory.ui.theme.primaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.primaryLightMediumContrast
import com.example.myinventory.ui.theme.secondaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.secondaryLightMediumContrast
import com.example.myinventory.ui.theme.tertiaryContainerLightMediumContrast
import com.example.myinventory.viewmodels.ItemViewModel
import com.example.myinventory.viewmodels.UserViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import kotlinx.coroutines.launch
import java.util.Locale

// Custom number ticker component with up/down arrows
@Composable
fun TickerBox(modifier: Modifier = Modifier, upperclick: () -> Unit, lowerclick: () -> Unit){
    Column{
        // Increment Button
        IconButton(
            onClick = upperclick,
            modifier = Modifier
                .size(24.dp),
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = primaryLightMediumContrast,
                contentColor = onPrimaryLightMediumContrast
            )){
            Icon(
                imageVector = Icons.Filled.ArrowDropUp,
                contentDescription = stringResource(R.string.increase_quantity)
            )
        }
        // Decrement Button
        IconButton(
            onClick = lowerclick,
            modifier = Modifier
                .size(24.dp),
            colors = IconButtonDefaults.iconButtonColors(
                containerColor = primaryLightMediumContrast,
                contentColor = onPrimaryLightMediumContrast
            )){
            Icon(
                imageVector = Icons.Filled.ArrowDropDown,
                contentDescription = stringResource(R.string.decrease_quantity)
            )
        }
    }
}

// Text field with integrated ticker buttons for numeric input
@Composable
fun NumericalTickerField(number: String,
                         onValueChange: (String) -> Unit,
                         modifier: Modifier = Modifier,
                         setPrefix: @Composable (() -> Unit)? = null,
                         labelName: String = ""){


    OutlinedTextField(
        value = number,
        onValueChange = {
            onValueChange(it)
        },
        modifier = modifier,
        label = {Text(labelName) },
        prefix = setPrefix,
        trailingIcon = {
            TickerBox(
                upperclick = {
                    val newValue = (number.toDouble() + 1)
                    onValueChange(newValue.toString())
                },
                lowerclick = {
                    val newValue = (number.toDouble() - 1)
                    onValueChange(newValue.toString())
                }
            )
        },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        colors = inputBoxColors()
    )
}

// Main screen for viewing and editing item details
@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun ItemViewScreen(
    viewModel: ItemViewModel,
    itemId: Int,
    onBack: () -> Unit,
    userId: Long,
    userViewModel: UserViewModel
) {

    // Retrieve the item details using ViewModel
    val item by viewModel.getItemById(itemId).observeAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()


    // Display loading message if item data is not yet available
    if (item == null) {
        Box(modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center){
            Text("Loading item...",
                style = MaterialTheme.typography.headlineMedium)
        }
        return
    }

    var editedItem by remember {mutableStateOf(item!!)}
    val openDialog = remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    // Formatters for numeric values
    val localFormat = remember {
        NumberFormat.getInstance(Locale.getDefault()).apply{
            minimumFractionDigits = 2
            maximumFractionDigits = 2
            isGroupingUsed = true
        }
    }
    val localIntFormat = remember{
        NumberFormat.getIntegerInstance(Locale.getDefault()).apply{
            isGroupingUsed = true
        }
    }

    // Gallery Image Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) {uri: Uri? ->
        uri?.let{
            try{
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(it, takeFlags)
            } catch(e: SecurityException){
                e.printStackTrace()
            }
            editedItem = editedItem.copy(imagePath = uri.toString())
        }
    }

    // Helper for creating image URI asynchronously
    var photoUri by remember { mutableStateOf<Uri?>(null) }

    // Camera Launcher
    val takePhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) {success ->
        if (success && photoUri != null){
            editedItem = editedItem.copy(imagePath = photoUri.toString())
        }
    }

    // Dialog for renaming the item
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun NameChangeDialog() {
        var nameState by remember {mutableStateOf(editedItem.itemName)}
        BasicAlertDialog(onDismissRequest = { openDialog.value = false }) {
            Surface(
                modifier = Modifier
                    .wrapContentWidth()
                    .wrapContentHeight(),
                shape = MaterialTheme.shapes.medium,
                tonalElevation = AlertDialogDefaults.TonalElevation,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(stringResource(R.string.change_name))
                    Spacer(modifier = Modifier.height(24.dp))
                    OutlinedTextField(
                        value = nameState,
                        onValueChange = {nameState = it},
                        singleLine = true,
                        colors = inputBoxColors()
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { openDialog.value = false },
                            modifier = Modifier.padding(8.dp),
                            colors = ButtonDefaults.textButtonColors(
                                contentColor = tertiaryContainerLightMediumContrast
                            )
                        ) {
                            Text(stringResource(R.string.cancel))
                        }
                        TextButton(
                            onClick = {
                                editedItem = editedItem.copy(itemName = nameState)
                                openDialog.value = false
                            },
                            modifier = Modifier.padding(8.dp),
                            colors = ButtonDefaults.textButtonColors(
                                contentColor = secondaryContainerLightMediumContrast
                            )
                        ) {
                            Text(stringResource(R.string.confirm))
                        }
                    }
                }
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(stringResource(R.string.item_details)) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = onPrimaryContainerLightMediumContrast,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }, actions = {
                    // Delete Button
                    IconButton(
                        onClick = {
                            viewModel.deleteItem(editedItem)
                            onBack()
                        }) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = "Delete Item",
                            tint = errorContainerLightMediumContrast,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = primaryContainerLightMediumContrast,
                    titleContentColor = onPrimaryContainerLightMediumContrast
                )
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier
            .padding(innerPadding)
            .fillMaxSize()
            .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Item Image Display
            AsyncImage(
                model = editedItem.imagePath,
                fallback = painterResource(R.drawable.box_img),
                error = painterResource(R.drawable.box_img),
                contentDescription = "${editedItem.itemName} Image",
                modifier = Modifier
                    .size(250.dp)
                    .padding(top = 16.dp)
            )

            // Image Update Buttons (Gallery/Camera)
            Row(modifier = Modifier
                .padding(vertical = 16.dp)
                .fillMaxWidth(fraction = 0.6f),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(
                    onClick = { galleryLauncher.launch("image/*") },
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = secondaryLightMediumContrast,
                        contentColor = secondaryContainerLightMediumContrast
                    )) {Icon(
                    imageVector = Icons.Filled.Image,
                    contentDescription = "Gallery")}

                CameraPermissionWrapper(
                    onLaunchCamera = {
                        scope.launch {
                            val uri = createTempImageUri(context)
                            uri?.let {
                                photoUri = it
                                takePhotoLauncher.launch(it)
                            }
                        }
                    }
                ) { onClick ->
                    IconButton(onClick = onClick,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = secondaryLightMediumContrast,
                            contentColor = secondaryContainerLightMediumContrast
                        )
                    ){
                        Icon(
                            imageVector = Icons.Filled.PhotoCamera,
                            contentDescription = "Camera"
                        )
                    }
                }
            }
            HorizontalDivider()

            // Item Name with Edit Dialog Trigger
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ){
                Text(editedItem.itemName, style = MaterialTheme.typography.displayMedium)
                IconButton(onClick = { openDialog.value = true }) {
                    Icon(imageVector = Icons.Outlined.Edit, contentDescription = "Edit Name")
                }
            }

            if (openDialog.value){
                NameChangeDialog()
            }

            // Price and Quantity Editors
            Row(modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // Price Editor
                NumericalTickerField(
                    number = localFormat.format(editedItem.price),
                    onValueChange = {
                        val parsedPrice = if(it.isBlank()){
                            0.0
                        }else{
                            try{
                                localFormat.parse(it)?.toDouble()?: 0.0
                            }catch (e: Exception){
                                editedItem.price
                            }
                        }
                        editedItem = editedItem.copy(price = parsedPrice)
                    },
                    modifier = Modifier.width(175.dp),
                    setPrefix = {
                        Icon(
                            imageVector = Icons.Filled.AttachMoney,
                            contentDescription = "Money Sign"
                        )
                    },
                    labelName = stringResource(R.string.price)
                )

                // Quantity Editor
                NumericalTickerField(
                    number = localIntFormat.format(editedItem.quantity),
                    onValueChange = {
                        val parsedQnty = if (it.isBlank()){
                            0
                        }else{
                            try{
                                localIntFormat.parse(it)?.toInt()?: 0
                            }catch(e: Exception){
                                editedItem.quantity
                            }
                        }
                        editedItem = editedItem.copy(quantity = parsedQnty)
                    },
                    modifier = Modifier.width(175.dp),
                    labelName = stringResource(R.string.quantity)
                )
            }
            
            // Location Dropdowns
            Row(modifier = Modifier
                .fillMaxWidth(fraction = 0.9f),
                horizontalArrangement = Arrangement.SpaceBetween
            ){
                val shelfs = (1..10).map {it.toString()}
                val aisles = ('A'..'Z').map {it.toString()}
                
                LocationDropDown(
                    items = shelfs,
                    label = stringResource(R.string.shelf),
                    selected = editedItem.shelf.toString(),
                    onValueChanged = {editedItem = editedItem.copy(shelf = it.toInt())},
                    modifier = Modifier.weight(1f).padding(end = 4.dp)
                )

                LocationDropDown(
                    items = aisles,
                    label = stringResource(R.string.aisle),
                    selected = editedItem.aisle,
                    onValueChanged = {editedItem = editedItem.copy(aisle = it)},
                    modifier = Modifier.weight(1f).padding(start = 4.dp)
                )
            }

            // Description Editor
            OutlinedTextField(
                value = editedItem.description ?: "",
                onValueChange = {editedItem = editedItem.copy(description = it)},
                label = { Text(stringResource(R.string.description)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                maxLines = 5,
                colors = inputBoxColors(),
                modifier = Modifier
                    .padding(vertical = 16.dp)
                    .fillMaxWidth(fraction = 0.9f)
                    .height(150.dp)
            )

            // Save Changes Button
            SmsPermissionWrapper(
                onPermissionGranted = {userViewModel.getUserPhoneNumber(userId){
                    viewModel.checkAndSendLowStockAlert(
                        phoneNumber = it,
                        itemId = editedItem.id,
                        itemName = editedItem.itemName,
                        quantity = editedItem.quantity
                ) }
                    onBack()},
                userId = userId,
                userViewModel = userViewModel) { onClick ->
                FilledTonalButton(
                    onClick = {
                        viewModel.updateItem(editedItem)
                        onClick()  // Request permission + send
                    },
                    modifier = Modifier.padding(20.dp),
                    enabled = item != editedItem,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = primaryLightMediumContrast,
                        contentColor = onPrimaryLightMediumContrast
                    )
                ) {
                    Text(stringResource(R.string.save_changes))
                }
            }
        }
    }
}
