package com.example.myinventory.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.TextFieldLineLimits
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.OutlinedSecureTextField
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.myinventory.R
import com.example.myinventory.ui.theme.inputBoxColors
import com.example.myinventory.ui.theme.inverseOnSurfaceLightMediumContrast
import com.example.myinventory.ui.theme.inversePrimaryLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.primaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.primaryLightMediumContrast
import com.example.myinventory.ui.theme.secondaryContainerLightMediumContrast
import com.example.myinventory.viewmodels.UserViewModel

// Hero Image Component for the Login Screen
@Composable
fun LoginImage(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier
            .size(275.dp),
        shape = CircleShape,
        shadowElevation = 8.dp,
    ) {
        Image(
            painter = painterResource(R.drawable.login_image),
            contentDescription = "My Inventory Logo Image",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
        )
    }
}


// Main Login Screen Composable
@Composable
fun LoginScreen(
    viewModel: UserViewModel,
    onLoginSuccess: (Long) -> Unit,
    onSignUpClick: () -> Unit
) {
    // State holders for input fields
    val username = rememberTextFieldState()
    val password = rememberTextFieldState()

    // State to track if login attempt failed
    var failedLogin by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()


    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(primaryLightMediumContrast),
    ) { innerPadding ->
        Column( modifier = Modifier
            .padding(innerPadding)
            .fillMaxSize()
            .verticalScroll(scrollState),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Hero Image
            LoginImage(modifier = Modifier.padding(top = 40.dp))

            // Username Input Field
            OutlinedTextField(
                state = username,
                label = {
                    Text(stringResource(R.string.username))
                },
                placeholder = {
                    stringResource(R.string.username)
                },
                isError = failedLogin,
                supportingText = {
                    if (failedLogin) {
                        Text(stringResource(R.string.usrnm_pwrd_error))
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                lineLimits = TextFieldLineLimits.SingleLine,
                colors = inputBoxColors(),
                modifier = Modifier
                    .padding(top = 32.dp, bottom = 8.dp)
                    .fillMaxWidth(fraction = 0.75f)
            )
            // Password Input Field (Secure)
            OutlinedSecureTextField(
                state = password,
                label = { Text(stringResource(R.string.password)) },
                isError = failedLogin,
                supportingText = {
                    if (failedLogin) {
                        Text(stringResource(R.string.usrnm_pwrd_error))
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                colors = inputBoxColors(),
                modifier = Modifier
                    .padding(top = 8.dp, bottom = 8.dp)
                    .fillMaxWidth(fraction = 0.75f)
            )
            // Login Button
            FilledTonalButton(
                onClick = {
                    viewModel.authenticate(username.text.toString(), password.text.toString()){
                        success, userId ->
                       if(success) {
                           onLoginSuccess(userId)
                       }else{
                           failedLogin = true
                       }
                    }
                },
                enabled = username.text.isNotEmpty() && password.text.length >= 10,
                modifier = Modifier
                    .padding(top = 16.dp, bottom = 8.dp)
                    .fillMaxWidth(fraction = 0.35f),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = primaryContainerLightMediumContrast,
                    contentColor = onPrimaryContainerLightMediumContrast,
                    disabledContainerColor = inversePrimaryLightMediumContrast,
                    disabledContentColor = inverseOnSurfaceLightMediumContrast
                ),
                content = {Text(stringResource(R.string.login))}
            )

            // Button to navigate to Sign Up Screen
            TextButton(
                onClick = onSignUpClick,
                modifier = Modifier,
                colors = ButtonDefaults.textButtonColors(
                    contentColor = secondaryContainerLightMediumContrast
                ),
                content = {Text(stringResource(R.string.sign_up_title))}
            )
        }
    }
}
