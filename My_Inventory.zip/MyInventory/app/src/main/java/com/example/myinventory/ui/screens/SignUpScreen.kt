package com.example.myinventory.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.TextFieldLineLimits
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedSecureTextField
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.myinventory.R
import com.example.myinventory.data.models.User
import com.example.myinventory.ui.theme.inputBoxColors
import com.example.myinventory.ui.theme.inverseOnSurfaceLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.onSecondaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.outlineVariantLightMediumContrast
import com.example.myinventory.ui.theme.primaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.secondaryContainerLightMediumContrast
import com.example.myinventory.viewmodels.UserViewModel
import org.mindrot.jbcrypt.BCrypt

// Screen composable for user registration
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignUpScreen(
    viewModel: UserViewModel,
    onSignUpSuccess: (Long) -> Unit,
    onBack: () -> Unit) {
    // variables to hold user input with recomposition
    val username = rememberTextFieldState()
    val password = rememberTextFieldState()
    val confirmPassword = rememberTextFieldState()
    val employeeID = rememberTextFieldState()

    // Track usernameTaken
    var usernameTakenError by remember{mutableStateOf(false)}
    // Check Username validity: length must be > 7 chars and no spaces
    val usernameError = remember{
        derivedStateOf {
            username.text.length in 1..7 ||
            username.text.contains(" ")
        }
    }
    var usernameErrorMessage by remember{mutableStateOf("")}

    // Check Password validity: must be 10+ chars (1-9 invalid), no spaces, contain digit and special char
    val passwordError = remember{
        derivedStateOf {
            password.text.length in 1..9 ||
            password.text.contains(" ") ||
            !password.text.any { it.isDigit() } ||
            !password.text.any { "!#$%&*_-@.,?".contains(it) }
        }
    }

    // Check Confirm Password matches original password
    val confirmError = remember{ derivedStateOf { confirmPassword.text != password.text }}

    // Check Employee ID validity: must be > 7 digits and contain no spaces
    val employeeIdError = remember {
        derivedStateOf {
            employeeID.text.length in 1..7 ||
            employeeID.text.contains(" ") ||
            !employeeID.text.all { it.isDigit() }
        }
    }

    // temporary list of roles for ui development
    val roles = listOf("Laborer", "Supervisor", "Executive")
    var expanded by remember { mutableStateOf(false)}
    val selectedRole = rememberTextFieldState(roles[0])
    val scrollState = rememberScrollState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {Text(stringResource(R.string.sign_up_title))},
                navigationIcon = {
                    IconButton(onClick = onBack){
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = onPrimaryContainerLightMediumContrast
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = primaryContainerLightMediumContrast,
                    titleContentColor = onPrimaryContainerLightMediumContrast
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // username input field
            OutlinedTextField(
                state = username,
                label = { Text(stringResource(R.string.username)) },
                isError = usernameError.value || usernameTakenError,
                supportingText = {
                    if (usernameError.value) {
                        Text(stringResource(R.string.username_error))
                    }else if (usernameTakenError) {
                        Text(usernameErrorMessage)
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                lineLimits = TextFieldLineLimits.SingleLine,
                colors = inputBoxColors(),
                modifier = Modifier
                    .padding(top = 125.dp, bottom = 4.dp)
                    .fillMaxWidth(fraction = 0.75f)
            )
            // password input field
            OutlinedSecureTextField(
                state = password,
                label = { Text(stringResource(R.string.password)) },
                isError = passwordError.value,
                supportingText = {
                    if (passwordError.value) {

                        Text(stringResource(R.string.pwrd_error))
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                colors = inputBoxColors(),
                modifier = Modifier
                    .padding(vertical = 4.dp)
                    .fillMaxWidth(fraction = 0.75f)
            )
            // confirm password input field
            OutlinedSecureTextField(
                state = confirmPassword,
                label = { Text(stringResource(R.string.confirm_password)) },
                isError = confirmError.value,
                supportingText = {
                    if (confirmError.value) {
                        Text(stringResource(R.string.confirm_pwrd_error))
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                colors = inputBoxColors(),
                modifier = Modifier
                    .padding(vertical = 4.dp)
                    .fillMaxWidth(fraction = 0.75f)
            )
            // Employee ID input field
            OutlinedTextField(
                state = employeeID,
                label = { Text(stringResource(R.string.employee_id)) },
                isError = employeeIdError.value,
                supportingText = {
                    if (employeeIdError.value) {
                        Text(stringResource(R.string.employeeID_error))
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                lineLimits = TextFieldLineLimits.SingleLine,
                colors = inputBoxColors(),
                modifier = Modifier
                    .padding(vertical = 4.dp)
                    .fillMaxWidth(fraction = 0.75f)
            )
            // Account Type dropdown menu
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded },
                modifier = Modifier
                    .padding(vertical = 4.dp)
                    .fillMaxWidth(fraction = 0.75f)
            ){
                OutlinedTextField(
                    state = selectedRole,
                    label = { Text(stringResource(R.string.account_type))},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    colors = inputBoxColors(),
                    modifier = Modifier
                        .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable)
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                ) {
                    roles.forEach { role -> DropdownMenuItem(
                        text = {Text(role)},
                        onClick = {
                            selectedRole.edit {replace(0, length, role) }
                            expanded = false
                        }
                    ) }
                }
            }
            // Create Account button triggers registration logic
            FilledTonalButton(
                onClick = {
                    viewModel.userNameTaken(userName = username.text.toString()){isTaken->
                        if(!isTaken){
                            viewModel.registerUser(User(
                                userName = username.text.toString(),
                                employeeId = employeeID.text.toString().toInt(),
                                role = selectedRole.text.toString()
                            ),
                                passwordRaw = password.text.toString(),
                                onSuccess = {onSignUpSuccess(it)})
                        } else{
                            usernameTakenError = true
                            usernameErrorMessage = "Username is Taken"
                        }
                    }
                },

                enabled = !usernameError.value &&
                        !passwordError.value &&
                        !employeeIdError.value &&
                        !confirmError.value &&
                        username.text.isNotBlank() &&
                        password.text.isNotBlank() &&
                        confirmPassword.text.isNotBlank() &&
                        employeeID.text.isNotBlank(),
                modifier = Modifier
                    .padding(top = 16.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = secondaryContainerLightMediumContrast,
                    contentColor = onSecondaryContainerLightMediumContrast,
                    disabledContainerColor = outlineVariantLightMediumContrast,
                    disabledContentColor = inverseOnSurfaceLightMediumContrast
                ),
                content = {Text(stringResource(R.string.create_account))}
            )
        }
    }
}
