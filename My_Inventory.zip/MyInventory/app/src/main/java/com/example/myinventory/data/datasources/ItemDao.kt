package com.example.myinventory.data.datasources

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.myinventory.data.models.Item

// Data Access Object for accessing Item data in the database
@Dao
interface ItemDao {

    // Insert a new item into the database
    @Insert
    suspend fun insertItem(item: Item)

    // Update an existing item in the database
    @Update
    suspend fun updateItem(item: Item)

    // Delete an item from the database
    @Delete
    suspend fun deleteItem(item: Item)

    // Delete multiple items from the database in a single transaction
    @Delete
    suspend fun deleteItems(items: List<Item>)

    // Get item by item ID
    @Query("SELECT * FROM items WHERE ItemID = :itemId")
    fun findItembyId(itemId: Int): LiveData<Item>

    // Search with partial match
    @Query("SELECT * FROM items WHERE itemName LIKE '%' || :query || '%' " +
            "ORDER BY itemName ASC")
    fun findItems(query: String): LiveData<List<Item>>

    // Get all Items
    @Query("SELECT * FROM items")
    fun getAllItems(): LiveData<List<Item>>

}
