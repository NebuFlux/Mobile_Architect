@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.myinventory.ui.screens

import android.content.Intent
import android.icu.text.NumberFormat
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.myinventory.R
import com.example.myinventory.data.models.Item
import com.example.myinventory.ui.components.CameraPermissionWrapper
import com.example.myinventory.ui.components.createTempImageUri
import com.example.myinventory.ui.theme.inputBoxColors
import com.example.myinventory.ui.theme.inverseOnSurfaceLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.onSecondaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.outlineVariantLightMediumContrast
import com.example.myinventory.ui.theme.primaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.secondaryContainerLightMediumContrast
import com.example.myinventory.viewmodels.ItemViewModel
import kotlinx.coroutines.launch
import java.util.Locale

// Custom Dropdown Composable for Location Selection (Shelf/Aisle)
@Composable
fun LocationDropDown(
    items: List<String>,
    label: String,
    selected: String? = null,
    onValueChanged: (String) -> Unit,
    modifier: Modifier = Modifier) {
    // Variable to hold selected item with recomposition
    val selectedItem = remember(selected){selected ?: items.first()}
    // Variable to toggle dropdown menu
    var expanded by remember { mutableStateOf(false)}

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = modifier
            .padding(vertical = 4.dp)
    ){
        OutlinedTextField(
            value = selectedItem,
            onValueChange = {},
            label = { Text(label)},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors = inputBoxColors(),
            modifier = Modifier
                .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable)
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            items.forEach { item -> DropdownMenuItem(
                text = {Text(item)},
                onClick = {
                    onValueChanged(item)
                    expanded = false
                }
            ) }
        }
    }
}

// Main Composable for adding a new item to the inventory
@Composable
fun AddItemScreen(
    viewModel: ItemViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    // variables to hold user input with recomposition
    var itemName by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf(0) }
    var price by remember { mutableStateOf(0.0) }
    var description by remember { mutableStateOf("") }
    var selectedShelf by remember {mutableStateOf("1")}
    var selectedAisle by remember {mutableStateOf("A")}
    var imageUri by remember {mutableStateOf<Uri?>(null)}

    // Temporary shelfs and aisles variables for ui development
    val shelfs = (1..10).map {it.toString()}
    val aisles = ('A'..'Z').map {it.toString()}

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val scrollState = rememberScrollState()

    // Launcher for selecting an image from the gallery
    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                // Persist permission to read this URI across reboots
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
            } catch (e: SecurityException) {
                e.printStackTrace()
            }
            imageUri = uri
        }
    }

    // Launcher for taking a photo with the camera
    val takePhotoLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) {success ->
        if (success){}
    }

    // Validate form inputs dynamically
    val isFormValid by remember{
        derivedStateOf {
            itemName.isNotBlank() &&
            quantity > 0 &&
            price > 0.0
        }
    }

    // Formatters for displaying numbers and currency
    val localFormat = remember {
        NumberFormat.getInstance(Locale.getDefault()).apply{
            minimumFractionDigits = 2
            maximumFractionDigits = 2
            isGroupingUsed = true
        }
    }
    val localIntFormat = remember{
        NumberFormat.getIntegerInstance(Locale.getDefault()).apply{
            isGroupingUsed = true
        }
    }

        Scaffold(modifier = modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {Text(stringResource(R.string.add_item_title))},
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = onPrimaryContainerLightMediumContrast
                        )
                    }
                },
                 actions = {
                     // Gallery Selection Button
                     IconButton(onClick = {
                         galleryLauncher.launch("image/*")
                     }) {Icon(
                         imageVector = Icons.Filled.Image,
                         contentDescription = "Gallery",
                         tint = onPrimaryContainerLightMediumContrast)}
                     
                     // Camera Button with permission check
                     CameraPermissionWrapper(
                         onLaunchCamera = {
                             scope.launch {
                                 // Create URI on background thread to avoid UI jank
                                 val uri = createTempImageUri(context)
                                 uri?.let {
                                     imageUri = it
                                     takePhotoLauncher.launch(it)
                                 }
                             }
                         }
                     ) { onClick ->
                         IconButton(onClick = onClick){
                             Icon(
                                 imageVector = Icons.Filled.PhotoCamera,
                                 contentDescription = "Camera",
                                 tint = onPrimaryContainerLightMediumContrast
                             )
                        }
                     }
                 },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = primaryContainerLightMediumContrast,
                    titleContentColor = onPrimaryContainerLightMediumContrast
                )
            )
        }
        ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Item Name Input Field
            OutlinedTextField(
                value = itemName,
                onValueChange = {itemName = it},
                label = { Text(stringResource(R.string.item_name)) },
                trailingIcon = {
                    if (itemName.isNotEmpty()){
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = "Valid"
                        )}
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                singleLine = true,
                colors = inputBoxColors(),
                modifier = Modifier
                    .padding(top = 32.dp, bottom = 4.dp)
                    .fillMaxWidth(fraction = 0.75f)
            )

            // Quantity Input Field
            OutlinedTextField(
                value = localIntFormat.format(quantity),
                onValueChange = {
                    val parsedQnty = if (it.isBlank()){
                        0
                    }else{
                        try{
                            localIntFormat.parse(it)?.toInt()?: 0
                        }catch(e: Exception){
                            quantity
                        }
                    }
                    quantity = parsedQnty
                },
                label = { Text(stringResource(R.string.quantity)) },
                trailingIcon = {
                    if (quantity > 0){
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = "Valid"
                    )}
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                colors = inputBoxColors(),
                modifier = Modifier
                    .padding(vertical = 4.dp)
                    .fillMaxWidth(fraction = 0.75f)
            )

            // Price Input Field
            OutlinedTextField(
                value = localFormat.format(price),
                onValueChange = {
                    val parsedPrice = if(it.isBlank()){
                        0.0
                    }else{
                        try{
                            localFormat.parse(it)?.toDouble()?: 0.0
                        }catch (e: Exception){
                            price
                        }
                    }
                    price = parsedPrice
                },
                label = { Text(stringResource(R.string.price)) },
                prefix =  {
                    Icon(
                        imageVector = Icons.Default.AttachMoney,
                        contentDescription = "Dollars"
                    )
                },
                trailingIcon = {
                    if (price > 0.0){
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = "Valid"
                        )}
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                colors = inputBoxColors(),
                modifier = Modifier
                    .padding(vertical = 4.dp)
                    .fillMaxWidth(fraction = 0.75f)
            )
            
            // Location Dropdowns Row
            Row(modifier = Modifier
                .fillMaxWidth(fraction = 0.75f),
                horizontalArrangement = Arrangement.SpaceBetween
            ){
                LocationDropDown(
                    items = shelfs,
                    label = stringResource(R.string.shelf),
                    selected = selectedShelf,
                    onValueChanged = {selectedShelf = it},
                    modifier = Modifier.weight(1f).padding(end = 4.dp)
                )

                LocationDropDown(
                    items = aisles,
                    label = stringResource(R.string.aisle),
                    selected = selectedAisle,
                    onValueChanged = {selectedAisle = it},
                    modifier = Modifier.weight(1f).padding(start = 4.dp)
                )
            }
            
            // Description Input Field
            OutlinedTextField(
                value = description,
                onValueChange = {description = it},
                label = { Text(stringResource(R.string.description)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                maxLines = 5,
                colors = inputBoxColors(),
                modifier = Modifier
                    .padding(vertical = 4.dp)
                    .fillMaxWidth(fraction = 0.75f)
                    .fillMaxHeight(fraction = 0.35f)
            )

            // Add Item Button
            FilledTonalButton(
                onClick = {
                    val newItem = Item(
                        itemName = itemName,
                        price = price,
                        quantity = quantity,
                        imagePath = imageUri?.toString(),
                        description = description,
                        shelf = selectedShelf.toInt(),
                        aisle = selectedAisle
                    )
                    viewModel.insertItem(newItem)
                    onBack()
                },
                enabled = isFormValid,
                modifier = Modifier
                    .padding(top = 16.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = secondaryContainerLightMediumContrast,
                    contentColor = onSecondaryContainerLightMediumContrast,
                    disabledContainerColor = outlineVariantLightMediumContrast,
                    disabledContentColor = inverseOnSurfaceLightMediumContrast
                ),
                content = {Text(stringResource(R.string.add_item))}
            )

        }
    }
}
