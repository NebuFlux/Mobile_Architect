package com.example.myinventory.data.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

// Entity class representing an Item in the 'items' table
@Entity(tableName = "items",
    indices = [Index(value = ["itemName"])])
data class Item (

    // Primary key for the item, auto-generated
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "ItemId")
    val id: Int = 0,

    // Name of the item
    @ColumnInfo(name = "itemName")
    val itemName: String = "",

    // Price of the item
    @ColumnInfo(name = "price")
    val price: Double = 99.99,

    // Quantity available in stock
    @ColumnInfo(name = "quantity")
    val quantity: Int = 0,

    // File path to the item's image
    @ColumnInfo(name = "imagePath")
    val imagePath: String? = null,

    // Description of the item
    @ColumnInfo(name = "description")
    val description: String? = null,

    // Shelf location of the item
    @ColumnInfo(name = "shelf")
    val shelf: Int = 0,

    // Aisle location of the item
    @ColumnInfo(name = "aisle")
    val aisle: String = "A"

) {
    // Convenience constructor for creating items without an ID
    constructor(
         itemName: String = "",
         price: Double = 99.99,
         quantity: Int = 0,
         imagePath: String? = null,
         description: String? = null,
         shelf: Int = 0,
         aisle: String = "A"
    ): this(
        id=0,
        itemName = itemName,
        price = price,
        quantity = quantity,
        imagePath = imagePath,
        description = description,
        shelf = shelf,
        aisle = aisle
    )
}
