package com.example.myinventory.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.myinventory.data.MyInventoryRoomDatabase
import com.example.myinventory.data.models.Item
import com.example.myinventory.data.repositories.ItemRepository
import com.example.myinventory.ui.components.SmsHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// ViewModel for managing Item data and UI state
class ItemViewModel (application: Application) : AndroidViewModel(application){
    private val repository: ItemRepository

    // LiveData for holding all items in the inventory
    val allItems: LiveData<List<Item>>
    // MediatorLiveData to handle both search results and full list
    val searchResults = MediatorLiveData<List<Item>>()
    
    // MutableLiveData for current search query and active search status
    private val currentQuery = MutableLiveData("")
    private val isSearchActive = MutableLiveData<Boolean>(false)
    // Tracks current data source (all items vs search results)
    private var currentSource: LiveData<List<Item>>? = null

    // Track alerts sent to prevent spamming during same session
    private val sentAlerts = mutableSetOf<Int>()

    init {
        // Initialize DAO and Repository
        val itemDao = MyInventoryRoomDatabase.getDatabase(application).itemDao()
        repository = ItemRepository(itemDao)
        allItems = repository.allItems

        // Start by displaying all items
        updateSource(allItems)

        // Refresh list whenever query or search status changes
        searchResults.addSource(currentQuery){
            refreshList()
        }

        searchResults.addSource(isSearchActive){
            refreshList()
        }
    }

    // Call when user types in search dialog
    fun setSearchQuery(query: String) {
        currentQuery.value = query.trim()
    }

    // Call when user toggles the FilterChip
    fun setSearchActive(active: Boolean) {
        isSearchActive.value = active
        if (!active) {
            currentQuery.value = ""
        }
    }

    // Refreshes the displayed list based on search state
    private fun refreshList() {
        val query = currentQuery.value.orEmpty()

        // If search is active and query is not empty, perform search
        if (isSearchActive.value == true && query.isNotBlank()) {
            val liveData = repository.searchItems("%$query%")
            updateSource(liveData)
        } else {
            // Otherwise, show all items
            updateSource(allItems)
        }
    }

    // Updates the source LiveData for the MediatorLiveData
    private fun updateSource(newSource: LiveData<List<Item>>){
        if (currentSource == newSource) return

        currentSource?.let{searchResults.removeSource(it)}

        currentSource = newSource
        searchResults.addSource(newSource) {
            searchResults.value = it
        }
    }

    // Retrieve a single item by ID
    fun getItemById(id: Int): LiveData<Item> {
       return repository.getItemById(id)
    }

    // Insert a new item via repository
    fun insertItem(item: Item) = viewModelScope.launch {
        repository.insertItem(item)
    }

    // Update an existing item via repository
    fun updateItem(item: Item) = viewModelScope.launch {
        repository.updateItem(item)
    }

    // Delete an item via repository
    fun deleteItem(item: Item) = viewModelScope.launch{
        repository.deleteItem(item)
    }

    // Batch delete items
    fun deleteItems(items: List<Item>) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteItems(items)
    }

    // Check and send low stock alert
    fun checkAndSendLowStockAlert(phoneNumber: String, itemId: Int, itemName: String,
                                  quantity: Int) {
        // Only send if quantity is 0 or less and we haven't already sent an alert for this item ID this session
        if (quantity <= 0 && sentAlerts.add(itemId)) {
            viewModelScope.launch(Dispatchers.IO) {
                // Use application context to avoid leaking Activity context
                SmsHelper.sendLowStockAlert(getApplication(),
                    phoneNumber,
                    itemName,
                    quantity)
            }
        }
    }
}
