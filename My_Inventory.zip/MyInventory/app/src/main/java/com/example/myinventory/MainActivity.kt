package com.example.myinventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.myinventory.ui.screens.AddItemScreen
import com.example.myinventory.ui.screens.GridViewScreen
import com.example.myinventory.ui.screens.ItemViewScreen
import com.example.myinventory.ui.screens.LoginScreen
import com.example.myinventory.ui.screens.SignUpScreen
import com.example.myinventory.ui.theme.MyInventoryTheme
import com.example.myinventory.viewmodels.ItemViewModel
import com.example.myinventory.viewmodels.UserViewModel
import kotlinx.serialization.Serializable

// Main entry point for the MyInventory application
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Enable edge-to-edge display for a modern look
        enableEdgeToEdge()
        setContent {
            MyInventoryTheme {
                Surface(modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background){
                    // Initialize the Navigation Controller
                    val navController = rememberNavController()
                    // Initialize shared ViewModels
                    val itemViewModel: ItemViewModel by viewModels<ItemViewModel>()
                    val userViewModel: UserViewModel by viewModels<UserViewModel>()
                    
                    // Launch the main app composable
                    MyInventoryApp(navController = navController,
                        itemViewModel = itemViewModel,
                        userViewModel = userViewModel)
                }
            }
        }
    }
}

// Composable function that hosts the navigation graph
@Composable
fun MyInventoryApp(
    navController: NavHostController,
    itemViewModel: ItemViewModel,
    userViewModel: UserViewModel) {
    
    // Define the Navigation Host with the start destination
    NavHost(
        navController = navController,
        startDestination = LoginRoute
    ) {
        // Login Screen Destination
        composable<LoginRoute> {
            LoginScreen(
                viewModel = userViewModel,
                onLoginSuccess ={userId ->
                    // Navigate to Inventory on successful login and clear backstack
                    navController.navigate(InventoryRoute(userId)){
                        popUpTo<LoginRoute> { inclusive = true}
                    }
                },
                onSignUpClick = {
                    navController.navigate(SignupRoute)
                }
            )
        }

        // Sign Up Screen Destination
        composable<SignupRoute> {
            SignUpScreen(
                viewModel = userViewModel,
                onSignUpSuccess ={userId ->
                    // Navigate to Inventory on success and clear backstack
                    navController.navigate(InventoryRoute(userId)){
                        popUpTo<LoginRoute> {inclusive = true}
                    }
                },
                onBack = {
                    // Navigate back to Login
                    navController.navigate(LoginRoute){
                        popUpTo<LoginRoute>{inclusive = true}
                    }
                }
            )
        }

        // Inventory Grid Screen Destination
        composable<InventoryRoute> { backStackEntry ->
            val args = backStackEntry.toRoute<InventoryRoute>()
            GridViewScreen(
                viewModel = itemViewModel,
                onAddItem = { navController.navigate(AddItemRoute) },
                onItemClick = { itemId ->
                    navController.navigate(ItemRoute(itemId, args.userId))
                }
            )
        }

        // Item Detail Screen Destination (requires itemId argument)
        composable<ItemRoute> { backStackEntry ->
            val args = backStackEntry.toRoute<ItemRoute>()
            ItemViewScreen(
                itemId = args.itemId,
                userId = args.userId,
                viewModel = itemViewModel,
                userViewModel = userViewModel,
                onBack = {navController.popBackStack()}
            )
        }

        // Add Item Screen Destination
        composable<AddItemRoute>{
            AddItemScreen(
                viewModel = itemViewModel,
                onBack = {navController.popBackStack()}
            )
        }
    }
}

// Serializable objects for Type-Safe Navigation
@Serializable object LoginRoute
@Serializable
data class InventoryRoute(
    val userId: Long
)
@Serializable object SignupRoute
@Serializable object AddItemRoute
@Serializable
data class ItemRoute(
    val itemId: Int,
    val userId: Long
)
