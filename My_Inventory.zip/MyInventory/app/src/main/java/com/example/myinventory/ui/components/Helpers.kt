package com.example.myinventory.ui.components

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.telephony.SmsManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.myinventory.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// Singleton helper for SMS operations
object SmsHelper {
    // Sends a low stock alert SMS if permission is granted
    fun sendLowStockAlert(context: Context, phoneNumber: String, itemName: String, currentQuantity: Int) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) !=
            PackageManager.PERMISSION_GRANTED) {
            return
        }
        try {
            val smsManager = context.getSystemService(SmsManager::class.java)

            val message = context.getString(R.string.zero_quantity, itemName, currentQuantity)

            // Send the text in the background
            smsManager.sendTextMessage(
                phoneNumber,
                null,
                message,
                null,
                null
            )
            Log.d("SmsHelper", context.getString(R.string.sms_successfull))
        } catch (e: Exception) {
            Log.e("SmsHelper", context.getString(R.string.sms_failed), e)
        }
    }
}

// Helper function to create a temporary image URI on the IO thread
suspend fun createTempImageUri(context: Context): Uri? {
    return withContext(Dispatchers.IO) {
        val contentValues = ContentValues().apply{
            put(MediaStore.Images.Media.DISPLAY_NAME,
                "item_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg")
        }
        context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues)
    }
}
