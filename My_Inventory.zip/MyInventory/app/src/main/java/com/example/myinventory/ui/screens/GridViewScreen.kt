package com.example.myinventory.ui.screens

import android.icu.text.NumberFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.input.TextFieldLineLimits
import androidx.compose.foundation.text.input.TextFieldState
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.example.myinventory.R
import com.example.myinventory.data.models.Item
import com.example.myinventory.ui.theme.errorContainerLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.onPrimaryLightMediumContrast
import com.example.myinventory.ui.theme.onTertiaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.primaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.secondaryContainerLightMediumContrast
import com.example.myinventory.ui.theme.tertiaryContainerLightMediumContrast
import com.example.myinventory.viewmodels.ItemViewModel
import java.util.Locale

// Dialog for searching items in the inventory
@Composable
fun SearchDialog(onDismiss: () -> Unit,
                 onSearch: () -> Unit,
                 query: TextFieldState) {


    AlertDialog(
        onDismissRequest = onDismiss,
        title = {Text(stringResource(R.string.search_inventory))},
        text = {
            // Text field for search query input
            OutlinedTextField(
                state = query,
                label = { Text(stringResource(R.string.search_label)) },
                lineLimits = TextFieldLineLimits.SingleLine,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton ={
            TextButton(
                onClick = {
                onSearch()
                onDismiss()}
            ){
                Text(stringResource(R.string.search))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

// Composable filter chip to toggle search/filter
@Composable
fun FilterChip(
    selected: Boolean,
    onClick: () -> Unit
){
    FilterChip(
        onClick = onClick,
        label = { Text("Filter")},
        selected = selected,
        leadingIcon =
            {
                Icon(
                    imageVector =
                        if (selected) {
                            ImageVector.vectorResource(R.drawable.filter_lines)
                        } else {
                            ImageVector.vectorResource(R.drawable.no_filter_lines)
                        },
                    contentDescription = "Filter Icon",
                    modifier = Modifier.size(FilterChipDefaults.IconSize)
                )
            },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = secondaryContainerLightMediumContrast,
            labelColor = onTertiaryContainerLightMediumContrast,
            iconColor = onTertiaryContainerLightMediumContrast,
            selectedContainerColor = tertiaryContainerLightMediumContrast,
            selectedLabelColor = onTertiaryContainerLightMediumContrast,
            selectedLeadingIconColor = onTertiaryContainerLightMediumContrast
        )
    )
}

// Individual Card representing a single Inventory Item
@Composable
fun ItemCard(inventoryItem: Item,
             onClick: () -> Unit = {},
             modifier: Modifier = Modifier,
             ) {

    // Number formatters for localized display
    val localFormat = remember {
        NumberFormat.getInstance(Locale.getDefault()).apply{
            minimumFractionDigits = 2
            maximumFractionDigits = 2
            isGroupingUsed = true
        }
    }
    val localIntFormat = remember{
        NumberFormat.getIntegerInstance(Locale.getDefault()).apply{
            isGroupingUsed = true
        }
    }
    Card(
        onClick = onClick,
        modifier = modifier
            .size(150.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = MaterialTheme.shapes.medium
    ) {
        Box(modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)){
            // Asynchronously load item image using Coil
            AsyncImage(
                model= inventoryItem.imagePath,
                fallback = painterResource(R.drawable.box_img),
                error = painterResource(R.drawable.box_img),
                contentDescription = "${inventoryItem.itemName} Image",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .matchParentSize()
                    .align(Alignment.Center)
                    .clip(MaterialTheme.shapes.medium)
            )
            // Overlay for better text readability
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(Color.Black.copy(alpha = 0.3f))
            )
            Text(inventoryItem.itemName, modifier = Modifier
                .padding(4.dp)
                .align(Alignment.TopStart),
                style = MaterialTheme.typography.titleSmall,
                color = onPrimaryLightMediumContrast)
            Column(modifier = Modifier.align(Alignment.BottomStart)) {
                Text("$${localFormat.format(inventoryItem.price)}", modifier = Modifier
                    .padding(horizontal = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = onPrimaryLightMediumContrast)
                Text("QTY: ${localIntFormat.format(inventoryItem.quantity)}", modifier = Modifier
                    .padding(horizontal = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = onPrimaryLightMediumContrast)
            }
        }
    }
}

// Row of items in the grid, handling layout and deletions
@Composable
fun InventoryRow(
    rowItems: List<Item>,
    onItemClick: (Int) -> Unit,
    modifier: Modifier = Modifier,
    onDeleteRow: () -> Unit
    ) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start,
        modifier = modifier.fillMaxWidth()
    ) {
        // Button to delete entire row of items
        IconButton(
            onClick = onDeleteRow,
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Delete,
                contentDescription = "Delete Row",
                tint = errorContainerLightMediumContrast,
                modifier = Modifier.size(32.dp)
            )
        }

        // Render each item in the row
        rowItems.forEach { item ->
            ItemCard(
                inventoryItem = item,
                onClick = {onItemClick(item.id)},
                modifier = Modifier
                    .weight(1f)
                    .padding(4.dp)
            )
        }

        // Fill remaining space if row is not full
        if (rowItems.size < 3) {
            repeat(3 - rowItems.size) {
                Box(modifier = Modifier.weight(1f))
            }
        }
    }
}

// Grid layout for displaying inventory items
@Composable
fun InventoryGrid(items: List<Item>,
                  onItemClick: (Int) -> Unit,
                  viewModel: ItemViewModel,
                  modifier: Modifier = Modifier) {

    // Chunk items into rows of 3
    val rowItems = remember(items) {items.chunked(3)}

    LazyColumn(
        contentPadding = PaddingValues(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.padding(8.dp)
    ) {
        items(rowItems){row ->
            InventoryRow(rowItems = row,
                onItemClick = onItemClick,
                onDeleteRow = {
                    for (item in row){
                        viewModel.deleteItem(item)
                    }
                })
        }
    }
}

// Main screen for viewing inventory grid
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GridViewScreen(
    viewModel: ItemViewModel,
    onAddItem: () -> Unit,
    onItemClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    // Observe search results from ViewModel
    val items by viewModel.searchResults.observeAsState(emptyList())
    var showSearchDialog by remember {mutableStateOf(false)}
    var isFilterSelected by remember {mutableStateOf(false)}
    val query = rememberTextFieldState("")

    if (showSearchDialog){
        SearchDialog(
            query = query,
            onDismiss = {showSearchDialog = false},
            onSearch = {
                viewModel.setSearchQuery(query.text.toString())
                isFilterSelected = query.text.isNotBlank()
                viewModel.setSearchActive(isFilterSelected)
                showSearchDialog = false
            }
        )
    }

    Scaffold(modifier = modifier.fillMaxSize(),
    topBar ={
        CenterAlignedTopAppBar(
            title = {Text(stringResource(R.string.my_inventory_title))},
            navigationIcon = {
                // Navigate to Add Item Screen
                IconButton(
                    onClick = onAddItem) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = "Add Item",
                        tint = onPrimaryContainerLightMediumContrast,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }, actions = {
                // Toggle Filter/Search Dialog
                FilterChip(
                    selected = isFilterSelected,
                    onClick = { showSearchDialog = true}
                )
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = primaryContainerLightMediumContrast,
                titleContentColor = onPrimaryContainerLightMediumContrast
            )
        )
    }) { innerPadding ->
        InventoryGrid(
            items = items,
            onItemClick = onItemClick,
            viewModel = viewModel,
            modifier = Modifier
                .padding(innerPadding))
    }

}
